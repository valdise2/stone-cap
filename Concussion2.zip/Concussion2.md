```python
import pandas as pd

file_path = "Norm_Ath_Data.csv"
df = pd.read_csv(file_path)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Sex</th>
      <th>Sport</th>
      <th>Concussion History</th>
      <th>Concussion Number</th>
      <th>Anxiety Diagnosis</th>
      <th>Anxiety Symptoms</th>
      <th>Depression Diagnosis</th>
      <th>Number of Prior Depressive Episodes</th>
      <th>PCS Symptom Frequency</th>
      <th>...</th>
      <th>Headache</th>
      <th>Dizziness</th>
      <th>Fatigue</th>
      <th>Light Sensitivity</th>
      <th>Mentally Foggy</th>
      <th>Difficulty Concentrating</th>
      <th>Less Sleep</th>
      <th>Irritability</th>
      <th>Sadness</th>
      <th>Nervousness</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>13</td>
      <td>Female</td>
      <td>Hockey</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>13</td>
      <td>Female</td>
      <td>Hockey</td>
      <td>Yes</td>
      <td>2</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>14</td>
      <td>Female</td>
      <td>Rugby</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>14</td>
      <td>Female</td>
      <td>Rugby</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>Yes</td>
      <td>No</td>
      <td>4</td>
      <td>8</td>
      <td>...</td>
      <td>4</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>15</td>
      <td>Female</td>
      <td>Soccer</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>0</td>
      <td>1</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>143</th>
      <td>15</td>
      <td>Male</td>
      <td>Hockey</td>
      <td>No</td>
      <td>0</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>No</td>
      <td>0</td>
      <td>5</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>5</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>144</th>
      <td>13</td>
      <td>Male</td>
      <td>Soccer</td>
      <td>No</td>
      <td>0</td>
      <td>No</td>
      <td>No</td>
      <td>Yes</td>
      <td>2</td>
      <td>9</td>
      <td>...</td>
      <td>4</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>145</th>
      <td>16</td>
      <td>Male</td>
      <td>Lacrosse</td>
      <td>Yes</td>
      <td>1</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>4</td>
      <td>4</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>146</th>
      <td>17</td>
      <td>Male</td>
      <td>Lacrosse</td>
      <td>Yes</td>
      <td>1</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>4</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>147</th>
      <td>16</td>
      <td>Male</td>
      <td>Hockey</td>
      <td>No</td>
      <td>0</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>4</td>
      <td>15</td>
      <td>...</td>
      <td>0</td>
      <td>2</td>
      <td>5</td>
      <td>6</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>4</td>
      <td>3</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
<p>148 rows × 22 columns</p>
</div>




```python
# Removing additional columns
columns_to_remove = [
    'Anxiety Diagnosis',
    'Anxiety Symptoms',
    'Number of Prior Depressive Episodes',
    'PCS Symptom Frequency',
    'Difficulty Concentrating',
    'Less Sleep',
    'Irritability',
    'Nervousness',
    'Light Sensitivity',
    'Fatigue'
]

simple_df = df.drop(columns = columns_to_remove, errors = 'ignore')

simple_df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Sex</th>
      <th>Sport</th>
      <th>Concussion History</th>
      <th>Concussion Number</th>
      <th>Depression Diagnosis</th>
      <th>PCS Symptom Severity</th>
      <th>Total MFQ Score</th>
      <th>Headache</th>
      <th>Dizziness</th>
      <th>Mentally Foggy</th>
      <th>Sadness</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>13</td>
      <td>Female</td>
      <td>Hockey</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>13</td>
      <td>Female</td>
      <td>Hockey</td>
      <td>Yes</td>
      <td>2</td>
      <td>No</td>
      <td>0</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>14</td>
      <td>Female</td>
      <td>Rugby</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>14</td>
      <td>Female</td>
      <td>Rugby</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>27</td>
      <td>10</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>15</td>
      <td>Female</td>
      <td>Soccer</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>15</td>
      <td>Female</td>
      <td>Rugby</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>2</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>15</td>
      <td>Female</td>
      <td>Rugby</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>0</td>
      <td>15</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>15</td>
      <td>Female</td>
      <td>Rugby</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>7</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>8</th>
      <td>15</td>
      <td>Female</td>
      <td>Cheerleading</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>7</td>
      <td>11</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>15</td>
      <td>Female</td>
      <td>Hockey</td>
      <td>Yes</td>
      <td>1</td>
      <td>No</td>
      <td>18</td>
      <td>13</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Saving updated dataset as CSV
simple_df.to_csv('/Users/dominicvaldiserri/Downloads/Simplified_Ath_Data.csv', index=False)
```


```python
# Custom min-max scaling for symptom scores (0 to 6 scaled as percentage)
symptom_cols = ["Headache", "Dizziness", "Mentally Foggy", "Sadness"]
simple_df[symptom_cols] = simple_df[symptom_cols] / 6.0
```


```python
# Custom min-max scaling for Age (13 to 18 -> 0 to 1)
simple_df["Age"] = (simple_df["Age"] - 13) / (18 - 13)
```


```python
# Min-max scale remaining numeric columns
other_numeric_cols = ["Concussion Number", "PCS Symptom Severity", "Total MFQ Score"]
scaler = MinMaxScaler()
simple_df[other_numeric_cols] = scaler.fit_transform(simple_df[other_numeric_cols])

simple_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Sex</th>
      <th>Sport</th>
      <th>Concussion History</th>
      <th>Concussion Number</th>
      <th>Depression Diagnosis</th>
      <th>PCS Symptom Severity</th>
      <th>Total MFQ Score</th>
      <th>Headache</th>
      <th>Dizziness</th>
      <th>Mentally Foggy</th>
      <th>Sadness</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0</td>
      <td>Female</td>
      <td>Hockey</td>
      <td>Yes</td>
      <td>0.333333</td>
      <td>No</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0</td>
      <td>Female</td>
      <td>Hockey</td>
      <td>Yes</td>
      <td>0.666667</td>
      <td>No</td>
      <td>0.000000</td>
      <td>0.094340</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.2</td>
      <td>Female</td>
      <td>Rugby</td>
      <td>Yes</td>
      <td>0.333333</td>
      <td>No</td>
      <td>0.000000</td>
      <td>0.075472</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.2</td>
      <td>Female</td>
      <td>Rugby</td>
      <td>Yes</td>
      <td>0.333333</td>
      <td>No</td>
      <td>0.259615</td>
      <td>0.188679</td>
      <td>0.666667</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.4</td>
      <td>Female</td>
      <td>Soccer</td>
      <td>Yes</td>
      <td>0.333333</td>
      <td>No</td>
      <td>0.009615</td>
      <td>0.018868</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>143</th>
      <td>0.4</td>
      <td>Male</td>
      <td>Hockey</td>
      <td>No</td>
      <td>0.000000</td>
      <td>No</td>
      <td>0.125000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.166667</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>144</th>
      <td>0.0</td>
      <td>Male</td>
      <td>Soccer</td>
      <td>No</td>
      <td>0.000000</td>
      <td>Yes</td>
      <td>0.230769</td>
      <td>0.188679</td>
      <td>0.666667</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>145</th>
      <td>0.6</td>
      <td>Male</td>
      <td>Lacrosse</td>
      <td>Yes</td>
      <td>0.333333</td>
      <td>Yes</td>
      <td>0.115385</td>
      <td>0.150943</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>146</th>
      <td>0.8</td>
      <td>Male</td>
      <td>Lacrosse</td>
      <td>Yes</td>
      <td>0.333333</td>
      <td>Yes</td>
      <td>0.000000</td>
      <td>0.094340</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>147</th>
      <td>0.6</td>
      <td>Male</td>
      <td>Hockey</td>
      <td>No</td>
      <td>0.000000</td>
      <td>Yes</td>
      <td>0.500000</td>
      <td>0.584906</td>
      <td>0.000000</td>
      <td>0.333333</td>
      <td>0.333333</td>
      <td>0.5</td>
    </tr>
  </tbody>
</table>
<p>148 rows × 12 columns</p>
</div>




```python
# Saving updated dataset as CSV
simple_df.to_csv('/Users/dominicvaldiserri/Downloads/Simplified_Ath_Data2.csv', index=False)
```


```python
# One-hot encoding the specified categorical columns
columns_to_encode = ['Sex', 'Sport', 'Concussion History', 'Depression Diagnosis']
df_encoded= pd.get_dummies(simple_df, columns=columns_to_encode, drop_first=False, dtype=int)

df_encoded
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Concussion Number</th>
      <th>PCS Symptom Severity</th>
      <th>Total MFQ Score</th>
      <th>Headache</th>
      <th>Dizziness</th>
      <th>Mentally Foggy</th>
      <th>Sadness</th>
      <th>Sex_Female</th>
      <th>Sex_Male</th>
      <th>Sport_Cheerleading</th>
      <th>Sport_Hockey</th>
      <th>Sport_Lacrosse</th>
      <th>Sport_Rugby</th>
      <th>Sport_Soccer</th>
      <th>Concussion History_No</th>
      <th>Concussion History_Yes</th>
      <th>Depression Diagnosis_No</th>
      <th>Depression Diagnosis_Yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0</td>
      <td>0.333333</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0</td>
      <td>0.666667</td>
      <td>0.000000</td>
      <td>0.094340</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.2</td>
      <td>0.333333</td>
      <td>0.000000</td>
      <td>0.075472</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.2</td>
      <td>0.333333</td>
      <td>0.259615</td>
      <td>0.188679</td>
      <td>0.666667</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.4</td>
      <td>0.333333</td>
      <td>0.009615</td>
      <td>0.018868</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>143</th>
      <td>0.4</td>
      <td>0.000000</td>
      <td>0.125000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.166667</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>144</th>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.230769</td>
      <td>0.188679</td>
      <td>0.666667</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>145</th>
      <td>0.6</td>
      <td>0.333333</td>
      <td>0.115385</td>
      <td>0.150943</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>146</th>
      <td>0.8</td>
      <td>0.333333</td>
      <td>0.000000</td>
      <td>0.094340</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>147</th>
      <td>0.6</td>
      <td>0.000000</td>
      <td>0.500000</td>
      <td>0.584906</td>
      <td>0.000000</td>
      <td>0.333333</td>
      <td>0.333333</td>
      <td>0.5</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>148 rows × 19 columns</p>
</div>




```python
import numpy as np
import scipy.stats as stats

# Split data into groups by concussion history
group_yes = df_encoded[df_encoded['Concussion History_Yes'] == 1]
group_no = df_encoded[df_encoded['Concussion History_No'] == 1]

# Define symptom variables
symptom_vars = ['Headache', 'Dizziness', 'Mentally Foggy', 'Sadness']

# Function to calculate 95% CI for the mean
def mean_confidence_interval(data, confidence=0.95):
    n = len(data)
    mean = np.mean(data)
    se = stats.sem(data)
    h = se * stats.t.ppf((1 + confidence) / 2., n-1)
    return mean, mean-h, mean+h, se

# Calculate CI for symptom variables in both groups
ci_results = []

for var in symptom_vars:
    for group_label, group in [('Concussion History = Yes', group_yes), ('Concussion History = No', group_no)]:
        mean, lower, upper, se = mean_confidence_interval(group[var])
        ci_results.append({
            'Group': group_label,
            'Variable': var,
            'Mean': mean,
            'Standard Error': se,
            '95% CI Lower': lower,
            '95% CI Upper': upper
        })

# Also calculate CI for proportion of Concussion History_Yes and Depression Diagnosis_Yes
binary_vars = ['Concussion History_Yes', 'Depression Diagnosis_Yes']
n_total = len(df_encoded)

for var in binary_vars:
    p = df_encoded[var].mean()
    se = np.sqrt(p * (1 - p) / n_total)
    ci_low, ci_up = stats.norm.interval(0.95, loc=p, scale=se)
    ci_results.append({
        'Group': 'Overall',
        'Variable': var,
        'Mean': p,
        'Standard Error': se,
        '95% CI Lower': ci_low,
        '95% CI Upper': ci_up
    })

ci_df = pd.DataFrame(ci_results)

ci_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Group</th>
      <th>Variable</th>
      <th>Mean</th>
      <th>Standard Error</th>
      <th>95% CI Lower</th>
      <th>95% CI Upper</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Concussion History = Yes</td>
      <td>Headache</td>
      <td>0.112319</td>
      <td>0.031107</td>
      <td>0.049666</td>
      <td>0.174971</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Concussion History = No</td>
      <td>Headache</td>
      <td>0.094771</td>
      <td>0.018213</td>
      <td>0.058642</td>
      <td>0.130900</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Concussion History = Yes</td>
      <td>Dizziness</td>
      <td>0.028986</td>
      <td>0.011931</td>
      <td>0.004954</td>
      <td>0.053017</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Concussion History = No</td>
      <td>Dizziness</td>
      <td>0.063725</td>
      <td>0.015586</td>
      <td>0.032808</td>
      <td>0.094643</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Concussion History = Yes</td>
      <td>Mentally Foggy</td>
      <td>0.061594</td>
      <td>0.022794</td>
      <td>0.015685</td>
      <td>0.107503</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Concussion History = No</td>
      <td>Mentally Foggy</td>
      <td>0.071895</td>
      <td>0.016504</td>
      <td>0.039156</td>
      <td>0.104635</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Concussion History = Yes</td>
      <td>Sadness</td>
      <td>0.083333</td>
      <td>0.032249</td>
      <td>0.018381</td>
      <td>0.148286</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Concussion History = No</td>
      <td>Sadness</td>
      <td>0.057190</td>
      <td>0.017143</td>
      <td>0.023183</td>
      <td>0.091196</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Overall</td>
      <td>Concussion History_Yes</td>
      <td>0.310811</td>
      <td>0.038044</td>
      <td>0.236246</td>
      <td>0.385376</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Overall</td>
      <td>Depression Diagnosis_Yes</td>
      <td>0.060811</td>
      <td>0.019644</td>
      <td>0.022309</td>
      <td>0.099313</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 
symptom_ci_df_sorted = ci_df.sort_values(by='Group', ascending=False)

# 
fig, ax = plt.subplots(figsize=(10, 6))

for i, (idx, row) in enumerate(symptom_ci_df_sorted.iterrows()):
    ax.errorbar(x=row['Mean'], y=i, xerr=[[row['Mean'] - row['95% CI Lower']], 
                                          [row['95% CI Upper'] - row['Mean']]], 
                fmt='o', label=row['Group'] if i % 2 == 0 else "", capsize=5)

ax.set_yticks(range(len(symptom_ci_df_sorted)))
ax.set_yticklabels(symptom_ci_df_sorted['Group'] + " - " + symptom_ci_df_sorted['Variable'])
ax.axvline(x=0, color='gray', linestyle='--')
ax.set_xlabel('Mean Symptom Severity (Scaled 0-1)')
ax.set_title('95% Confidence Intervals for Symptom Severity by Concussion History')
plt.tight_layout()
plt.show()

```


    
![png](output_9_0.png)
    



```python
# Extract proportions and confidence intervals for binary variables
binary_ci_df = ci_df[ci_df['Variable'].isin(['Concussion History_Yes', 'Depression Diagnosis_Yes'])]

# Bar chart with error bars for proportions
fig, ax = plt.subplots(figsize=(8, 5))

ax.bar(binary_ci_df['Variable'], binary_ci_df['Mean'], yerr=[
    binary_ci_df['Mean'] - binary_ci_df['95% CI Lower'],
    binary_ci_df['95% CI Upper'] - binary_ci_df['Mean']
], capsize=10, color='skyblue')

ax.set_ylim(0, 1)
ax.set_ylabel('Proportion')
ax.set_title('Proportions with 95% Confidence Intervals\n(Concussion History and Depression Diagnosis)')
plt.tight_layout()
plt.show()

```


    
![png](output_10_0.png)
    



```python
# Step 1: Bin symptom scores into categories
def categorize_symptom(val):
    if val == 0:
        return 'None'
    elif val <= 2/6:
        return 'Mild'
    elif val <= 4/6:
        return 'Moderate'
    else:
        return 'Severe'

# Apply categorization to relevant symptoms
binned_df = df_encoded.copy()
for var in ['Headache', 'Dizziness', 'Mentally Foggy', 'Sadness']:
    binned_df[var + '_Category'] = binned_df[var].apply(categorize_symptom)

# Step 2 & 3: Perform chi-square tests comparing each symptom category to concussion history
chi_square_results = []
from scipy.stats import chi2_contingency

for var in ['Headache_Category', 'Dizziness_Category', 'Mentally Foggy_Category', 'Sadness_Category']:
    contingency_table = pd.crosstab(binned_df['Concussion History_Yes'], binned_df[var])
    chi2, p, dof, expected = chi2_contingency(contingency_table)
    chi_square_results.append({
        'Symptom': var.replace('_Category', ''),
        'Chi2 Statistic': chi2,
        'p-value': p,
        'Degrees of Freedom': dof
    })

# Convert results to DataFrame
chi_square_df = pd.DataFrame(chi_square_results)

chi_square_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symptom</th>
      <th>Chi2 Statistic</th>
      <th>p-value</th>
      <th>Degrees of Freedom</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Headache</td>
      <td>2.107399</td>
      <td>0.550417</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Dizziness</td>
      <td>2.118602</td>
      <td>0.548159</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mentally Foggy</td>
      <td>0.886948</td>
      <td>0.828576</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Sadness</td>
      <td>2.104964</td>
      <td>0.550909</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Visualize the proportion of symptom severity levels by concussion history for each symptom

import seaborn as sns
import matplotlib.pyplot as plt

# Reshape data for plotting
plot_data = pd.DataFrame()

for var in ['Headache_Category', 'Dizziness_Category', 'Mentally Foggy_Category', 'Sadness_Category']:
    temp = pd.crosstab(binned_df['Concussion History_Yes'], binned_df[var], normalize='index')
    temp['Concussion History'] = temp.index.map({0: 'No', 1: 'Yes'})
    temp = temp.reset_index(drop=True).melt(id_vars='Concussion History', var_name='Symptom Level', value_name='Proportion')
    temp['Symptom'] = var.replace('_Category', '')
    plot_data = pd.concat([plot_data, temp], ignore_index=True)

# Define the desired order for symptom levels
severity_order = ['None', 'Mild', 'Moderate', 'Severe']

# Ensure Symptom Level is a categorical variable with the specified order
plot_data['Symptom Level'] = pd.Categorical(plot_data['Symptom Level'], categories=severity_order, ordered=True)

# Replot with the ordered severity levels
g = sns.catplot(
    data=plot_data.sort_values('Symptom Level'),
    x="Symptom Level", y="Proportion", hue="Concussion History",
    col="Symptom", kind="bar", height=4, aspect=1
)
g.set_titles("{col_name}")
g.set_axis_labels("Severity Level", "Proportion")
g.set_xticklabels(rotation=45)
plt.subplots_adjust(top=0.85)
g.fig.suptitle("Symptom Severity Distribution by Concussion History (Ordered)")
plt.show()
```

    /Users/dominicvaldiserri/anaconda3/lib/python3.11/site-packages/seaborn/axisgrid.py:118: UserWarning: The figure layout has changed to tight
      self._figure.tight_layout(*args, **kwargs)



    
![png](output_12_1.png)
    



```python
# Step 1: Bin symptom scores into categories
def categorize_symptom(val):
    if val == 0:
        return 'None'
    elif val <= 2/6:
        return 'Mild'
    elif val <= 4/6:
        return 'Moderate'
    else:
        return 'Severe'

# Apply categorization to relevant symptoms
binned_df2 = df_encoded.copy()
for var in ['Headache', 'Dizziness', 'Mentally Foggy', 'Sadness']:
    binned_df2[var + '_Category'] = binned_df[var].apply(categorize_symptom)

# Step 2 & 3: Perform chi-square tests comparing each symptom category to concussion history
chi_square_results = []
from scipy.stats import chi2_contingency

for var in ['Headache_Category', 'Dizziness_Category', 'Mentally Foggy_Category', 'Sadness_Category']:
    contingency_table = pd.crosstab(binned_df2['Depression Diagnosis_Yes'], binned_df2[var])
    chi2, p, dof, expected = chi2_contingency(contingency_table)
    chi_square_results.append({
        'Symptom': var.replace('_Category', ''),
        'Chi2 Statistic': chi2,
        'p-value': p,
        'Degrees of Freedom': dof
    })

# Convert results to DataFrame
chi_square_df2 = pd.DataFrame(chi_square_results)

chi_square_df2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symptom</th>
      <th>Chi2 Statistic</th>
      <th>p-value</th>
      <th>Degrees of Freedom</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Headache</td>
      <td>7.567296</td>
      <td>0.055854</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Dizziness</td>
      <td>12.610364</td>
      <td>0.005560</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mentally Foggy</td>
      <td>4.416377</td>
      <td>0.219872</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Sadness</td>
      <td>15.180899</td>
      <td>0.001668</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Reshape data for plotting by Depression Diagnosis
plot_data_depression = pd.DataFrame()

for var in ['Headache_Category', 'Dizziness_Category', 'Mentally Foggy_Category', 'Sadness_Category']:
    temp = pd.crosstab(binned_df2['Depression Diagnosis_Yes'], binned_df2[var], normalize='index')
    temp['Depression Diagnosis'] = temp.index.map({0: 'No', 1: 'Yes'})
    temp = temp.reset_index(drop=True).melt(id_vars='Depression Diagnosis', var_name='Symptom Level', value_name='Proportion')
    temp['Symptom'] = var.replace('_Category', '')
    plot_data_depression = pd.concat([plot_data_depression, temp], ignore_index=True)

# Ensure Symptom Level is a categorical variable with the specified order
plot_data_depression['Symptom Level'] = pd.Categorical(plot_data_depression['Symptom Level'], categories=severity_order, ordered=True)

# Plot grouped bar charts
g = sns.catplot(
    data=plot_data_depression.sort_values('Symptom Level'),
    x="Symptom Level", y="Proportion", hue="Depression Diagnosis",
    col="Symptom", kind="bar", height=4, aspect=1
)
g.set_titles("{col_name}")
g.set_axis_labels("Severity Level", "Proportion")
g.set_xticklabels(rotation=45)
plt.subplots_adjust(top=0.85)
g.fig.suptitle("Symptom Severity Distribution by Depression Diagnosis (Ordered)")
plt.show()

```

    /Users/dominicvaldiserri/anaconda3/lib/python3.11/site-packages/seaborn/axisgrid.py:118: UserWarning: The figure layout has changed to tight
      self._figure.tight_layout(*args, **kwargs)



    
![png](output_14_1.png)
    



```python
# Use symptom predictors for logistic regression predicting Concussion History
X_concussion_symptoms = binned_df[['Headache', 'Dizziness', 'Mentally Foggy', 'Sadness']]
X_concussion_symptoms = sm.add_constant(X_concussion_symptoms)
y_concussion = binned_df['Concussion History_Yes']

# Fit logistic regression model
logit_model_concussion_symptoms = sm.Logit(y_concussion, X_concussion_symptoms)
result_concussion_symptoms = logit_model_concussion_symptoms.fit()

# Summarize with odds ratios and confidence intervals
summary_df_concussion_symptoms = pd.DataFrame({
    'Variable': result_concussion_symptoms.params.index,
    'Coefficient': result_concussion_symptoms.params.values,
    'Odds Ratio': result_concussion_symptoms.params.apply(np.exp),
    'p-value': result_concussion_symptoms.pvalues,
    '95% CI Lower': np.exp(result_concussion_symptoms.conf_int()[0]),
    '95% CI Upper': np.exp(result_concussion_symptoms.conf_int()[1])
})

summary_df_concussion_symptoms
```

    Optimization terminated successfully.
             Current function value: 0.589161
             Iterations 7





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Variable</th>
      <th>Coefficient</th>
      <th>Odds Ratio</th>
      <th>p-value</th>
      <th>95% CI Lower</th>
      <th>95% CI Upper</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>const</th>
      <td>const</td>
      <td>-0.781040</td>
      <td>0.457930</td>
      <td>0.000285</td>
      <td>0.300320</td>
      <td>0.698253</td>
    </tr>
    <tr>
      <th>Headache</th>
      <td>Headache</td>
      <td>1.410043</td>
      <td>4.096133</td>
      <td>0.285624</td>
      <td>0.307837</td>
      <td>54.503826</td>
    </tr>
    <tr>
      <th>Dizziness</th>
      <td>Dizziness</td>
      <td>-6.187748</td>
      <td>0.002054</td>
      <td>0.033115</td>
      <td>0.000007</td>
      <td>0.609095</td>
    </tr>
    <tr>
      <th>Mentally Foggy</th>
      <td>Mentally Foggy</td>
      <td>-1.479065</td>
      <td>0.227851</td>
      <td>0.377854</td>
      <td>0.008511</td>
      <td>6.099545</td>
    </tr>
    <tr>
      <th>Sadness</th>
      <td>Sadness</td>
      <td>3.056613</td>
      <td>21.255450</td>
      <td>0.082619</td>
      <td>0.673708</td>
      <td>670.607839</td>
    </tr>
  </tbody>
</table>
</div>




```python
univariate_concussion_results = []

for symptom in ['Headache', 'Dizziness', 'Mentally Foggy', 'Sadness']:
    X_uni = sm.add_constant(binned_df[[symptom]])
    model_uni = sm.Logit(y_concussion, X_uni).fit(disp=0)
    univariate_concussion_results.append({
        'Symptom': symptom,
        'Coefficient': model_uni.params[symptom],
        'Odds Ratio': np.exp(model_uni.params[symptom]),
        'p-value': model_uni.pvalues[symptom],
        '95% CI Lower': np.exp(model_uni.conf_int().loc[symptom][0]),
        '95% CI Upper': np.exp(model_uni.conf_int().loc[symptom][1])
    })

# Create DataFrame for display
univariate_concussion_df = pd.DataFrame(univariate_concussion_results)

univariate_concussion_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symptom</th>
      <th>Coefficient</th>
      <th>Odds Ratio</th>
      <th>p-value</th>
      <th>95% CI Lower</th>
      <th>95% CI Upper</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Headache</td>
      <td>0.463050</td>
      <td>1.588913</td>
      <td>0.606853</td>
      <td>0.272348</td>
      <td>9.269938</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Dizziness</td>
      <td>-2.395215</td>
      <td>0.091153</td>
      <td>0.174713</td>
      <td>0.002868</td>
      <td>2.897162</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mentally Foggy</td>
      <td>-0.406596</td>
      <td>0.665913</td>
      <td>0.720785</td>
      <td>0.071627</td>
      <td>6.190969</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Sadness</td>
      <td>0.698707</td>
      <td>2.011151</td>
      <td>0.436358</td>
      <td>0.346217</td>
      <td>11.682639</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.metrics import precision_score, recall_score, roc_auc_score, accuracy_score

# Prepare data for the multivariate model
X_multi = sm.add_constant(binned_df[['Headache', 'Dizziness', 'Mentally Foggy', 'Sadness']])
y_multi = binned_df['Concussion History_Yes']

# Fit model and predict
model_multi = sm.Logit(y_multi, X_multi).fit(disp=0)
pred_probs_multi = model_multi.predict(X_multi)
pred_classes_multi = (pred_probs_multi >= 0.5).astype(int)

# Calculate metrics
accuracy_multi = accuracy_score(y_multi, pred_classes_multi)
precision_multi = precision_score(y_multi, pred_classes_multi, zero_division=0)
recall_multi = recall_score(y_multi, pred_classes_multi)
roc_auc_multi = roc_auc_score(y_multi, pred_probs_multi)

# Display results
evaluation_metrics = pd.DataFrame([{
    'Model': 'Multivariate Symptoms Model',
    'Accuracy': accuracy_multi,
    'Precision': precision_multi,
    'Recall': recall_multi,
    'ROC AUC': roc_auc_multi
}])

evaluation_metrics
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>ROC AUC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Multivariate Symptoms Model</td>
      <td>0.716216</td>
      <td>0.833333</td>
      <td>0.108696</td>
      <td>0.551471</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, ConfusionMatrixDisplay

# Generate ROC curve
fpr, tpr, thresholds = roc_curve(y_multi, pred_probs_multi)

# Create figure with two plots
fig, axs = plt.subplots(1, 2, figsize=(14, 6))

# Plot ROC Curve
axs[0].plot(fpr, tpr, label=f"AUC = {roc_auc_multi:.2f}")
axs[0].plot([0, 1], [0, 1], linestyle='--', color='gray')
axs[0].set_title("ROC Curve")
axs[0].set_xlabel("False Positive Rate")
axs[0].set_ylabel("True Positive Rate")
axs[0].legend()

# Plot Confusion Matrix
ConfusionMatrixDisplay.from_predictions(y_multi, pred_classes_multi, ax=axs[1], cmap="Blues")
axs[1].set_title("Confusion Matrix")

plt.tight_layout()
plt.show()
```


    
![png](output_18_0.png)
    



```python

```
